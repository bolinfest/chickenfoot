This folder contains demos that come with Chickenfoot.
They are like the samples, however, they do not contain go() as
the first line of the script because doing so would cause infinite loops.