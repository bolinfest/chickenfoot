
Every Chickenfoot toolbar icon should be a 48x24 PNG image, in which the left
24x24 half is the enabled version of the icon, and the right half is the
disabled version.  (Look at save-file.png for an example.)

To make a disabled version that looks consistent with the other disabled
icons, cover the icon with 50% transparent white.
