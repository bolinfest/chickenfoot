To build ChickenSleep...

...on Windows: open ChickenSleep.vcproj in Visual Studio .NET.

...on Linux or Mac: copy Makefile.default to Makefile and edit it appropriately.  Then run make.

