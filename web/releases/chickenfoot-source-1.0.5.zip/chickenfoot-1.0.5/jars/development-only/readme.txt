The JAR files in this directory are used only for developing Chickenfoot.  
They aren't needed in the release.
