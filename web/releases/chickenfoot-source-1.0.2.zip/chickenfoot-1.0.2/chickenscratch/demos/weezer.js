//go('http://www.weezer.com/karlscorner/news.asp')

select('[b] contains date in [td]')

//select('[b] contains date in [td] then [td]')
debug('done')
//debug( count('[b] contains date in [td]') )
//debug( count('[td]') )

