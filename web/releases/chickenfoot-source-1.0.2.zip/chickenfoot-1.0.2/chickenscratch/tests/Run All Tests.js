// ==UserScript==
// @extensionName Run All Tests
// @extensionDescription Runs all the Chickenfoot regression tests
// @extensionGUID 8b0f2de3-a9b7-9514-b1c9-04558e0194e7
// @version 1.0
// @name Run All Tests
// @when Pages Match
// @includes about:
// ==/UserScript==

include("tests/allTests.js")
