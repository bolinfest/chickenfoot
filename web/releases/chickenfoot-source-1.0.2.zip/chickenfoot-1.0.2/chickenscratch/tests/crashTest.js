window.addEventListener('click', 
    function() { fresh=1; output("PASS!") }, 
    false);

output("This is not an automatic test.")
output("To finish the test, just click")
output("on the web page a few times.")
output("If you see PASS! and Firefox doesn't")
output("crash, the test passes.")

