
var definedWithVar = 42;

function definedFunction() { return 102; }

globalVariable = 56;

Chickenfoot.Test.assertEquals("pages", scriptDir.leafName)

