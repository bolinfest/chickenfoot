
var definedWithVar = 42;

function definedFunction() { return 102; }

globalVariable = 56;

Test.assertEquals("pages", scriptDir.leafName)

