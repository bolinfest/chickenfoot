
// default includes
pref("extensions.@EXTENSION_NAME@.includes", @DEFAULT_INCLUDES@);

// default excludes
pref("extensions.@EXTENSION_NAME@.excludes", @DEFAULT_EXCLUDES@);
